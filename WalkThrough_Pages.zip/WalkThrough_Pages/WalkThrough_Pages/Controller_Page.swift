//
//  Controller_Page.swift
//  WalkThrough_Pages
//
//  Created by m on 7/22/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class Controller_Page: UIPageViewController,UIPageViewControllerDataSource,UIPageViewControllerDelegate {
    
    var storybordIDS = ["ID_page1","ID_page2","ID_page3","ID_page4"]
    var index = 0
    override func setViewControllers(_ viewControllers: [UIViewController]?, direction: UIPageViewControllerNavigationDirection, animated: Bool, completion: ((Bool) -> Void)? = nil) {
       
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        return storyboard?.instantiateViewController(withIdentifier:
            storybordIDS.last!) as? Page2
        
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        return storyboard?.instantiateViewController(withIdentifier:
            storybordIDS.last!) as? Page2    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        
        // Do any additional setup after loading the view.
    }

}
